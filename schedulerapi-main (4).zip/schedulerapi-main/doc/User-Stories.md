The Following is the whole user-stories related to the application (Activity-Scheduler):
For more about the user stories you have to read carefully the following [Guide](https://gist.github.com/seanh/8a5b7b36d5c4fdfcfbd3b42506296968).


- [Create an event](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/4) 
- [Delete an event](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/5)
- [Change an event’s Title](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/6)
- [Change an event’s Description](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/7)
- [Repeat an event ](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/8)
- [Change an event start-time](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/9)
- [Update an event End-time ](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/10)
- [Change an event reminder](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/11)
- [Cancel an event reminder ](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/12)
- [Retrieve the scheduled events during certain period](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/13)

<!--[Create holidays set](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/14)
- [Modify holidays set](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/15)
- [Eliminate a range of days from the holidays-set. ](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/16)
- [Retrieve holidays during certain period.](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/17)
- [Cancel hollidays reminder](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/18)
- [Create empty classes related to the functionality of the application ](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/19) 
- [Alert about the non-working days in advance](https://github.com/khawla-k-banydomi/ActivityScheduler/issues/21)-->

